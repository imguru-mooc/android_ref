#define LOG_TAG "Led"
#include <stdio.h>
#include "Led.h"

namespace android
{
	void Led::dataCallback(int ratio)
	{
		printf("Led::dataCallback(%d)\n", ratio);
	}
};
