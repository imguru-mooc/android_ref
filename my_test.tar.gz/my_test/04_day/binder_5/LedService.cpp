#define LOG_TAG "LedService"
#include <stdio.h>
#include "LedService.h"

namespace android
{
	void LedService::ledOn(void)
	{
		printf("LedService::ledOn(void)\n");
	}
	int LedService::ledRatio(int ratio)
	{
		printf("LedService::ledRatio(%d)\n", ratio);
		return ratio;
	}
	void LedService::connect( const sp<ILedClient> &client)
	{
		printf("LedService::connect()\n");
		client->dataCallback(111);
		client->dataCallback(111);
		client->dataCallback(111);
	}
};
