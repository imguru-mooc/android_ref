#define LOG_TAG "LedService"
#include <stdio.h>
#include <binder/Parcel.h>
#include "ILedService.h"

namespace android {
	class BpLedService : public BpInterface<ILedService>
	{
		public:
			explicit BpLedService(const sp<IBinder>& impl)
				: BpInterface<ILedService>(impl)
			{
			}

			virtual void ledOn(void)
			{
				Parcel data, reply;
				remote()->transact( LED_ON, data, &reply );
			}

			virtual int ledRatio(int ratio)
			{
				Parcel data, reply;
				int result;
				data.writeInt32( ratio );
				remote()->transact( LED_RATIO, data, &reply );
				result = reply.readInt32();
				return result;
			}
			virtual void connect( const sp<ILedClient> &client )
			{
				Parcel data, reply;
				data.writeStrongBinder(ILedClient::asBinder(client));
				remote()->transact( CONNECT, data, &reply );
			}
	};
	IMPLEMENT_META_INTERFACE(LedService, "android.os.ILedService");

	status_t BnLedService::onTransact(
			uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags)
	{
		switch (code) {
			case LED_ON: {
							 ledOn();
							 return NO_ERROR;
						 } break;
			case LED_RATIO: {
							int ratio;
							int result;
							ratio = data.readInt32();
							result = ledRatio(ratio);
							reply->writeInt32(result);
							return NO_ERROR;
						 } break;
			case CONNECT: {
							  sp<ILedClient> in_client;
							  data.readStrongBinder(&in_client);
							  connect(in_client);
							return NO_ERROR;
						 } break;
			default:
					 return BBinder::onTransact(code, data, reply, flags);
		}
	};
};
