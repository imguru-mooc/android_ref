
#ifndef ANDROID_ILED_SERVICE_H
#define ANDROID_ILED_SERVICE_H

#include <binder/IInterface.h>
#include "ILedClient.h"

namespace android {

// ----------------------------------------------------------------------

class ILedService : public IInterface
{
public:
    DECLARE_META_INTERFACE(LedService)

    virtual void ledOn( void ) = 0;
    virtual int ledRatio( int ) = 0;
    virtual void connect(const sp<ILedClient>&) = 0;

    enum {
        LED_ON = IBinder::FIRST_CALL_TRANSACTION,
		LED_RATIO,
		CONNECT
    };
};

// ----------------------------------------------------------------------

class BnLedService : public BnInterface<ILedService>
{
public:
    virtual status_t    onTransact( uint32_t code,
                                    const Parcel& data,
                                    Parcel* reply,
                                    uint32_t flags = 0);
};

// ----------------------------------------------------------------------------

}; // namespace android
#endif // ANDROID_ILED_SERVICE_H

