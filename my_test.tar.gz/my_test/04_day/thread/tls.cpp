
#if 1
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_key_t gTLS = 0;
void foo()
{
	int *count = (int*)pthread_getspecific(gTLS);
	if( count == 0 )
	{
		count = new int(0);
		pthread_setspecific(gTLS, count);
	}
	++*count;
	printf("foo(), count=%d\n", *count );
}
//---------------------------------------------------------------
void * my_handler_1(void* data)
{
	foo();
	foo();
	foo();
	return 0;
}
void * my_handler_2(void* data)
{
	foo();
	foo();
	return 0;
}

//-----------------------------------------------------------

void my_destructor(void* data)
{
	printf("my_destructor()\n");
	delete (int*)data;
}

int main()
{
	pthread_t mThread[2];
	pthread_key_create(&gTLS, my_destructor);
	pthread_create(&mThread[0], 0, my_handler_1, 0);
	pthread_create(&mThread[1], 0, my_handler_2, 0);
	pthread_join(mThread[0], 0 );
	pthread_join(mThread[1], 0 );
	return 0;
}
#endif
#if 0
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void foo()
{
	static int count=0;
	count++;
	printf("foo(), count=%d\n", count );
}
//---------------------------------------------------------------
void * my_handler_1(void* data)
{
	foo();
	foo();
	foo();
	return 0;
}
void * my_handler_2(void* data)
{
	foo();
	foo();
	return 0;
}

//-----------------------------------------------------------

int main()
{
	pthread_t mThread[2];
	pthread_create(&mThread[0], 0, my_handler_1, 0);
	pthread_create(&mThread[1], 0, my_handler_2, 0);
	pthread_join(mThread[0], 0 );
	pthread_join(mThread[1], 0 );
	return 0;
}
#endif
