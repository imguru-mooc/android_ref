#include <stdio.h>
#include "LedService.h"

namespace android {
	void LedService::ledOn(void)
	{
		printf("LedService::ledOn()\n");
	}
	int LedService::ledRatio(int ratio)
	{
		printf("LedService::ledOn(%d)\n", ratio);
		mRatio = ratio;
		return mRatio;
	}
};
