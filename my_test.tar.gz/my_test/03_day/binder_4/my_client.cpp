#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>
#include "ILedService.h"

using namespace android;

int main()
{
	sp<IBinder> binder;
	binder = defaultServiceManager()->getService(String16("led.service"));

	//Parcel data, reply;
	//binder->transact( 1, data, &reply );
	sp<ILedService> led = interface_cast<ILedService>(binder);
	led->ledOn();
	int ratio = led->ledRatio(200);
	printf("Client : ratio=%d\n", ratio );
	return 0;
}

