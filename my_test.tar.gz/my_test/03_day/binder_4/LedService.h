#ifndef ANDROID_LED_SERVICE_H
#define ANDROID_LED_SERVICE_H

#include "ILedService.h"

namespace android {

class LedService : public BnLedService
{
	int mRatio;
	public : 
		LedService():mRatio(0) {}
		virtual void ledOn(void);
		virtual int ledRatio(int);
};

};
#endif
