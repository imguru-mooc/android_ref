#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>
#include "LedService.h"

using namespace android;

int main()
{
	defaultServiceManager()->addService(
			 String16("led.service"), new LedService());
	ProcessState::self()->startThreadPool();
	IPCThreadState::self()->joinThreadPool();
	return 0;
}

