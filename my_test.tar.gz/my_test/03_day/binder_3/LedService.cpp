#include <stdio.h>
#include "LedService.h"

namespace android {
	void LedService::ledOn(void)
	{
		printf("LedService::ledOn()\n");
	}
};
