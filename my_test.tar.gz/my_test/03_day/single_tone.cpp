#if 1
#include <stdio.h>
class AAA 
{
private:
	static AAA *mObject;
	AAA(){ printf("open(/dev/binder)\n"); }

public:
	static AAA *self()
	{
		if( mObject == 0 )
			mObject = new AAA;
		return mObject;
	}
	~AAA(){ printf("AAA::~AAA()\n"); }
};

AAA *AAA::mObject = 0;

int main()
{
	AAA *p1 = AAA::self();
	AAA *p2 = AAA::self();
	return 0;
}
#endif
#if 0
#include <stdio.h>
class AAA 
{
private:
	static AAA *mObject;
	AAA(){ printf("AAA::AAA()\n"); }

public:
	static AAA *self()
	{
		if( mObject == 0 )
			mObject = new AAA;
		return mObject;
	}
	~AAA(){ printf("AAA::~AAA()\n"); }
};

AAA *AAA::mObject = 0;

int main()
{
	AAA *p1 = AAA::self();
	AAA *p2 = AAA::self();
	return 0;
}
#endif
