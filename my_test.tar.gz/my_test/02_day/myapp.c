#include <stdio.h>

int main()
{
    printf("hello android\n");
    return 0;
}

