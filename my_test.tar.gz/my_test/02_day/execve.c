#if 1
#include <stdlib.h>
#include <unistd.h>
int main()
{
	char *argv[] = {"ls", (char*)0};
	execve("/bin/ls", argv, 0);
	return 0;
}
#endif
#if 0
#include <stdlib.h>
#include <unistd.h>
int main()
{
	execlp("ls", "ls", (char*)0);
	return 0;
}
#endif

#if 0
#include <stdlib.h>
int main()
{
	system("ls");
	return 0;
}
#endif
