#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

void open_devnull_stdio(void)
{
	 int fd;
     static const char *name = "__null__";
     mknod(name, S_IFCHR | 0600, (1 << 8) | 3);
	 fd = open(name, O_RDWR);
	// unlink(name);
	 dup2(fd, 0); // fd_array[0] = fd_array[fd]
	 dup2(fd, 1); // fd_array[1] = fd_array[fd]
	 dup2(fd, 2); // fd_array[2] = fd_array[fd]

     if (fd > 2) {
         close(fd);
     }
}

int main()
{
	open_devnull_stdio();
	printf("hello world\n");
    return 0;
}
