#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/mman.h>

int main()
{
	char *p;
	int fd;
	fd = open("aaa", O_CREAT|O_TRUNC|O_RDWR, 0666);
	ftruncate(fd, 4096);
	p = mmap( 0 , 4096, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
	strcpy( p, "hello\n");
	munmap(p, 4096);
	return 0;
}
