#if 1
#include <stdio.h>
#define	__STRING(x)	#x
#define MAKE_STR(x) __STRING(x)

int main()
{
	char *p = "world"     MAKE_STR(hello);  // "world" "hello" 
	printf("[%s]\n", p );
	return 0;
}
#endif

#if 0
#define	____STRING(x)	#x
#define	__STRING(x) ____STRING(x)	
#define MAKE_STR(x) __STRING(x)

#define  hello world

int main()
{
	__STRING(hello);  // ____STRING(world) => #world => "world"
	return 0;
}
#endif

#if 0
#define	__STRING(x)	#x
#define MAKE_STR(x) __STRING(x)

#define  hello world

int main()
{
	__STRING(hello);  // #hello => "hello"
	return 0;
}
#endif
