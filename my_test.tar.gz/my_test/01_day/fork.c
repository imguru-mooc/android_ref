#if 1
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

void my_sig( int signo )
{
	printf("my_sig(%d)\n", signo );
	while( waitpid(-1,0,WNOHANG) > 0 )
		;
}

int main()
{
	int i,j;
	pid_t pid;
	signal( SIGCHLD, my_sig );

	for(i=0; i<5; i++)
	{
		pid = fork();
		if( pid == 0 )
		{
			for(j=0; j<i+1; j++)
			{
				printf("\t\t\t\tchild\n");
				sleep(1);
			}
			exit(4);
		}
	}
	while(1)
	{
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif
#if 0
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

void my_sig( int signo )
{
	printf("my_sig(%d)\n", signo );
	while( wait(0) > 0 )
		;
}

int main()
{
	int i,j;
	pid_t pid;
	signal( SIGCHLD, my_sig );

	for(i=0; i<5; i++)
	{
		pid = fork();
		if( pid == 0 )
		{
			for(j=0; j<i+1; j++)
			{
				printf("\t\t\t\tchild\n");
				sleep(1);
			}
			exit(4);
		}
	}
	while(1)
	{
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif
#if 0
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

void my_sig( int signo )
{
	printf("my_sig(%d)\n", signo );
	while( wait(0) > 0 )
		;
}

int main()
{
	int i,j;
	pid_t pid;
	signal( SIGCHLD, my_sig );

	for(i=0; i<20; i++)
	{
		pid = fork();
		if( pid == 0 )
		{
			for(j=0; j<3; j++)
			{
				printf("\t\t\t\tchild\n");
				sleep(1);
			}
			exit(4);
		}
	}
	while(1)
	{
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif
#if 0
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

void my_sig( int signo )
{
	printf("my_sig(%d)\n", signo );
	wait(0);
}

int main()
{
	int i,j;
	pid_t pid;
	signal( SIGCHLD, my_sig );

	for(i=0; i<20; i++)
	{
		pid = fork();
		if( pid == 0 )
		{
			for(j=0; j<3; j++)
			{
				printf("\t\t\t\tchild\n");
				sleep(1);
			}
			exit(4);
		}
	}
	while(1)
	{
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif
#if 0
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

void my_sig( int signo )
{
	printf("my_sig(%d)\n", signo );
	wait(0);
}

int main()
{
	int i;
	pid_t pid;
	signal( SIGCHLD, my_sig );
	pid = fork();
	if( pid == 0 )
	{
		for(i=0; i<3; i++)
		{
			printf("\t\t\t\tchild\n");
			sleep(1);
		}
		exit(4);
	}
	while(1)
	{
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif
#if 0
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
int main()
{
	int i;
	pid_t pid;
	pid = fork();
	if( pid == 0 )
	{
		for(i=0; i<3; i++)
		{
			printf("\t\t\t\tchild\n");
			sleep(1);
		}
		exit(4);
	}
	while(1)
	{
		wait(0);
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif
#if 0
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
int main()
{
	int i;
	pid_t pid;
	pid = fork();
	if( pid == 0 )
	{
		for(i=0; i<3; i++)
		{
			printf("\t\t\t\tchild\n");
			sleep(1);
		}
		exit(4);
	}
	while(1)
	{
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif



#if 0
#include <unistd.h>
#include <stdio.h>
int main()
{
	pid_t pid;
	pid = fork();
	if( pid == 0 )
		printf("child\n");
	else if (pid > 0 )
		printf("parent\n");
	return 0;
}
#endif

#if 0
#include <unistd.h>
#include <stdio.h>
int main()
{
	fork();
	printf("after\n");
	return 0;
}
#endif
