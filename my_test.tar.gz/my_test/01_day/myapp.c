#include <stdio.h>

int main()
{
	printf("hello android\n");
	printf("after android\n");

	return 0;
}
