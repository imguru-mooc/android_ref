#if 1
#include <stdio.h>
#include <unistd.h>

int main()
{
    fprintf(stderr, "hello");
	sleep(3);
	return 0;  //  fflush(stdout);
}
#endif
#if 0
#include <stdio.h>
#include <unistd.h>

int main()
{
    printf("hello");
	sleep(3);
	return 0;  //  fflush(stdout);
}
#endif
