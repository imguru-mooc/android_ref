#include <stdio.h>
#include <stdlib.h>
struct my_struct
{
	int count;
	int entry[0];
};

struct my_struct *p;

int main()
{
	//printf("sizeof(struct my_struct) = %lu\n", sizeof(struct my_struct));
	p = malloc( sizeof(struct my_struct) + sizeof(int)*10 );
	p->count = 10;
	p->entry[9] = 99;

	return 0;
}
