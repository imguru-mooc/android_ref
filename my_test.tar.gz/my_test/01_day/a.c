#include <stdio.h>
int main()
{
	printf("main()\n");
	return 0;
}
