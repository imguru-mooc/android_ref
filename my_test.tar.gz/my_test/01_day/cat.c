#include <fcntl.h>
#include <unistd.h>
int main(int argc, char **argv)
{
   char buff[128];
   int ret;
   int fd;

   if( argc == 2 )
   {
       fd = open( argv[1], O_RDONLY );
	   dup2(fd, 0);  // fd_array[0] = fd_array[3];
   }
   while( ret = read(0, buff, sizeof buff ))
   		write(1, buff, ret );
   return 0;
}
#if 0
#include <fcntl.h>
#include <unistd.h>
int main(int argc, char **argv)
{
   char buff[128];
   int ret;
   int fd;

   if( argc == 2 )
   {
       fd = open( argv[1], O_RDONLY );
	   close(0);
	   dup(fd);
   }
   while( ret = read(0, buff, sizeof buff ))
   		write(1, buff, ret );
   return 0;
}
#endif
