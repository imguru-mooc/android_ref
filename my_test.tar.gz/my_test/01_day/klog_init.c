#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

static int klog_fd;

void klog_init(void) {
	static const char* name = "kmsg";
	if (mknod(name, S_IFCHR | 0600, (1 << 8) | 11) == 0) {
		klog_fd = open(name, O_WRONLY | O_CLOEXEC);
	}
}

int main()
{
	klog_init();
	write( klog_fd, "hello world\n", 12 );
	return 0;
}

