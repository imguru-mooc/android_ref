interface ILedAuthService {
    void LEDON();
}

