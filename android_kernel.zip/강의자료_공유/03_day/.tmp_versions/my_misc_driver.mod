/root/android/my_test/03_day/my_misc_driver.ko
/root/android/my_test/03_day/my_misc_driver.o
